# Load required libraries
library(readxl)

# Load data
prodData <- read_excel("../data/DiscProd.xlsx")
prodDF <- data.frame(prodData)

fit2Data <- function(DF){

  # Plot the data
  plot(DF$Year,DF$DiscCum, xlab = "Year", ylab = "Discoveries (Gb)", main = "Cumulative Oil Discoveries")
  
  # Define logistic function
  # Ref: https://martinlab.chem.umass.edu/r-fitting-data/
  logistic <- function(x,Q,k,m,C) (Q/(1 + exp(-k*(x - m))) + C)
  
  # Initial parameters
  C0 <- min(DF$DiscCum)        # Offset from minimum
  Q0 <- max(DF$DiscCum) - C0   # Maximum discovered resources
  
  # The derivative of the logistic function:
  # dy/dx = k*Q*exp(-k*(x - m)) / (1 + exp(-k*(x - m)))^2
  # At x = m, dy/dx = k*Q/4 so if approximate slope at m is 
  # dy/dx ~= (f(x+1) - f(x-1))/2 
  # then 
  # k = 2 * (f(x+1) - f(x-1)) / Q = 2 * dy / L
  x_mid <- round(length(DF$Year)/2)
  dy <- DF$DiscCum[x_mid + 1] - DF$DiscCum[x_mid - 1]
  
  k0 <- 2 * dy / Q0            # Logistic growth rate, steepness of the curve
  x0 <- mean(DF$Year)          # Midpoint of the curve
  
  # Fit parameters
  logFit <- nls(DiscCum ~ logistic(Year,Q,k,m,C), data = DF, start = list(Q=Q0,k=k0,m=x0,C=C0))
  
  # Summary of fit parameters
  print(summary(logFit))
  
  # Fit model to data
  fitProd <- predict(logFit)
  
  # Overlay data plot
  lines(DF$Year,fitProd, col = "red")
  
  # Plot residuals
  fitResid <- DF$DiscCum - fitProd
  plot(DF$Year,fitResid, xlab = "Year", ylab = "Residuals (Gb)", main = "Discoveries Residuals")
  
  # Return fit paramters
  return(logFit)
}
