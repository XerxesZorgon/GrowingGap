% Plots energy derived from other sources relative to fossil fuel energy
% Data source: https://ourworldindata.org/energy-production-consumption
%
% Input(s)
%   owd: Array of consumption in TWh by source. First column is year.
%
% Output(s)
% Plot of energy fraction relative to fossile fuel use
%
% Example:
% pkg load io
% owd = csvread('..\data\global-energy-substitution.csv');
% OWD_FF_frac(owd)
%
% See also:
%
%
% Dependencies: pubFig

%
%
% Written by: John Peach 23-May-2021
% Wild Peaches
%
% Revisions:


function OWD_FF_frac(owd)

    % Delete top row, first two columns
    owd = owd(2:end,3:end);

    % Year
    Year = owd(:,1);

    % Extract energy types
    Wind = owd(:,2);
    Oil = owd(:,3);
    Nuc = owd(:,4);
    Hydro = owd(:,5);
    TradBio = owd(:,6);
    OtherRenew = owd(:,7);
    Biofuels = owd(:,8);
    Solar = owd(:,9);
    Coal = owd(:,10);
    Gas = owd(:,11);

    % Fossil fuels
    FossilFuels = Oil + Coal + Gas;

    % Ratios
    Wind_frac  = Wind ./ FossilFuels;
    Nuc_frac   = Nuc ./ FossilFuels;
    Hydro_frac = Hydro ./ FossilFuels;
    Biofuels_frac  = Biofuels ./ FossilFuels;
    Solar_frac = Solar ./ FossilFuels;

    % Plot ratios
    figure;
    plot(Year,100*[Wind_frac,Nuc_frac,Hydro_frac,Biofuels_frac,Solar_frac]);
    xlabel('Year');
    ylabel('Percent of FF');
    legend({'Wind', 'Nuclear', 'Hydro', 'Biofuels', 'Solar'},'Location','northwest');
    title('Energy fraction relative to fossil fuels');
    pubFig

    % Plot fossil fuel consumption by year
    figure;
    plot(Year,FossilFuels)
    xlabel('Year');
    ylabel('Fossil Fuels, TWh')
    title('Fossil fuel consumption')
    pubFig

endfunction
