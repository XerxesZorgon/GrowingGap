% Reads oil discovery and production data
% Ref: https://www.sciencedirect.com/science/article/pii/S2666049022000524
%
%
% Input(s)
%   Reads data from .csv files (raw discoveries and production)
%
% Output(s)
%   Saves interpolated data
%
% Example:
% Save image from Laherrere paper, load into WebPlotDigitizer
% Extract raw disvovery and production data to .csv files
% discProd;
%
% See also:
%
%

% Dependencies:
%
%
% 16-Jul-2022, John Peach
% Wild Peaches
%
% Revisions:


function discProd(plotFigs)

    % Read data files
    Discoveries_raw = csvread('../data/discoveries-raw.csv');
    Production_raw = csvread('../data/production-raw.csv');

    % Data cleanup
    Year = (1900:2020)';
    Discoveries = interp1(Discoveries_raw(:,1),Discoveries_raw,Year,'nearest');
    Production = interp1(Production_raw(:,1),Production_raw,Year,'cubic');

    % Save interpolated data
    csvwrite('../data/discoveries.csv',Discoveries);
    csvwrite('../data/production.csv',Production);

    if nargin == 1 && plotFigs
        close all
        % Plot discoveries
        figure;
        plot(Discoveries_raw(:,1),Discoveries_raw(:,2),Discoveries(:,1),Discoveries(:,2));
        xlabel('Year');
        ylabel('Discoveries Gb');
        legend({'Raw','Interp'});
        title('Annual Discoveries');
        pubFig

        % Plot production
        figure;
        plot(Production_raw(:,1),Production_raw(:,2),Production(:,1),Production(:,2));
        xlabel('Year');
        ylabel('Production Gb');
        legend({'Raw','Interp'});
        title('Annual Production');
        pubFig
    endif

endfunction
