function Plot_OPEC_reserve
% Plots estimated reserves for OPEC countries
%
%
% Input(s)
%   None
%
% Output(s)
%   Plots:
%     1) Declared reserves
%     2) Year-to-year changes
%     3) Probable reserves
%     4) Total OPEC reserves
%
% Example:
% Plot_OPEC_reserve
%
% See also:
%
%
% Dependencies: pubFig
%
%
%
% Written by: John Peach 12-Aug-2022
% Wild Peaches
%
% Revisions:

Oil = [ ...
1980 	28.00 	1.40 	58.00 	31.00 	65.40 	163.35 	17.87
1981 	29.00 	1.40 	57.50 	30.00 	65.90 	165.00 	17.95
1982 	30.60 	1.27 	57.00 	29.70 	64.48 	164.60 	20.30
1983 	30.51 	1.44 	55.31 	41.00 	64.23 	162.40 	21.50
1984 	30.40 	1.44 	51.00 	43.00 	63.90 	166.00 	24.85
1985 	30.50 	1.44 	48.50 	44.50 	90.00 	169.00 	25.85
1986 	31.00 	1.40 	47.88 	44.11 	89.77 	168.80 	25.59
1987 	31.00 	1.35 	48.80 	47.10 	91.92 	166.57 	25.00
1988 	92.21 	4.00 	92.85 	100.00 	91.92 	166.98 	56.30
1989 	92.20 	4.00 	92.85 	100.00 	91.92 	169.97 	58.08
1990 	92.20 	4.00 	93.00 	100.00 	95.00 	258.00 	59.00
1991 	92.20 	4.00 	93.00 	100.00 	94.00 	258.00 	59.00
1992 	92.20 	4.00 	93.00 	100.00 	94.00 	258.00 	62.70
2004 	92.20 	4.00 	132.00 	115.00 	99.00 	259.00 	78.00];
Yr = 1980:2004;
Oil = interp1(Oil(:,1),Oil,Yr);


figure; clf;

%-------------------------------------------------------------------------------
ttl = 'OPEC Reserves';
xlbl = 'Year';
ylbl = 'Declared Reserves (Gbl)';
lgnd = {'Abu Dhabi', 'Dubai', 'Iran', 'Iraq', 'Kuwait', 'Saudi Arabia' 'Venezuela'};

subplot(2,2,1)
plot(Oil(:,1),Oil(:,2:end));
xlabel(xlbl);
ylabel(ylbl);
title(ttl);
legend(lgnd);
pubFig

%-------------------------------------------------------------------------------
ttl  = 'Year to year reported reserve changes';
ylbl = 'Differnces (Gbl)';
OilDiff = diff(Oil(:,2:end));

subplot(2,2,2)
plot(Oil(2:end,1),OilDiff);
xlabel(xlbl);
ylabel(ylbl);
title(ttl);
legend(lgnd);
pubFig

%-------------------------------------------------------------------------------
ttl = 'Probable Reserves (Gbl)';
% lgnd = {'Claimed','Probable'};
Claimed = Oil(:,2:end);
JumpYr  = [1988 1988 1988 1988 1985 1990 1988];
Likely  = Claimed;
for cntry = 1:7
    Y = find(Yr == JumpYr(cntry));
    D = diff(Oil(Y-1:Y,cntry+1));
    Likely(Y:end,cntry) = Likely(Y:end,cntry) - D;
end;
subplot(2,2,3)
plot(Oil(:,1),Likely);
xlabel(xlbl);
ylabel(ylbl);
title(ttl);
legend(lgnd);
pubFig

%-------------------------------------------------------------------------------
ttl = 'Total OPEC Reserves';
lgnd = {'Claimed','Probable'};
Total_Claimed = sum(Claimed,2);
Total_Likely  = sum(Likely,2);

subplot(2,2,4)
plot(Oil(:,1),[Total_Claimed Total_Likely])
xlabel(xlbl);
ylabel(ylbl);
title(ttl);
legend(lgnd);
pubFig
