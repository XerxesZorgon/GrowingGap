% Plots EROI
% Ref: https://hal-ifp.archives-ouvertes.fr/hal-03186990/file/Long Term Estimates of the Energy-Return Cahiers de l'Economie n�113.pdf
%
% Input(s)
%   Year: Year of discovery
%   DiscCum: Cumulative discoveries
%
% Output(s)
%   Data written to EROI.csv file
%
% Example:
% discProd = csvread('../data/discProd.csv');
% Year = discProd(2:end,1);
% DiscCum = discProd(2:end,3);
%
% See also:
%
%
% Dependencies: pubFig

%
%
% Written by: John Peach 20-Jul-2022
% Wild Peaches
%
% Revisions:


function EROI(Year, DiscCum)

     # Constants
     Psi = 0.0000;
     psi = 658.31543;
     rho_tilde = 0.0005;
     epsilon = 44.3667;
     phi = 3.7925;

     # Functions
     G = @(rho) Psi + (1 - Psi) ./ (1 + exp(-psi .* (rho - rho_tilde)));
     H = @(rho) exp(-phi * rho);
     F = @(rho) G(rho) .* H(rho);

     # Plot as fraction of URR
     close all
     rho = linspace(0,1)';
     figure;
     plot(rho, [G(rho), H(rho), F(rho)]);
     xlabel('URR fraction');
     ylabel('EROI');
     legend({'Tech','Geo','Total'});
     title('EROI of Oil');
     pubFig

     # Plot as function of time
     URR = 5070;
     EROI_max = 1; %43;
     rho_year = DiscCum/URR;
     figure;
     EROI_mat = [G(rho_year), H(rho_year), F(rho_year)];
     plot(Year, EROI_max * EROI_mat);
     xlabel('Year');
     ylabel('EROI');
     legend({'Tech','Geo','Total'});
     title('EROI of Oil');
     pubFig

     # Save data
     fName = '../data/EROI.csv';
     csvwrite(fName,[Year EROI_mat]);

endfunction
