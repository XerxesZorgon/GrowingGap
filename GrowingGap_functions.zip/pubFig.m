% Modifies figures to get ready for publication                                    
%                                     
%                                     
% Input(s)                            
%   None                                  
%                                     
% Output(s)                           
%   Current figure revised, suitable for publication                                  
%                                     
% Example:                            
% t = linspace(0,2*pi);
% y = sin(t);
% figure; 
% plot(t,y);
% xlabel('Time')
% ylabel('sin(t)')
% title('Sine function')
% pubFig                                    
%                                     
% See also:                           
%                                     
%                                     
% Dependencies: None                      
                                      
%                                     
%                                     
% Written by: John Peach 20-Aug-2020  
% Wild Peaches
%                                     
% Revisions:                          
                                      
                                      
function pubFig  
    % Set standard units
    figUnits=get(gcf,'Units');
    set(gcf,'Units','inches');
    
    % Linewidth, fonts, figure dimensions
    linewidth = 1.5;
    axisFont  = 16; %12;
    labelFont = 20; %14;
    titleFont = 24; %16;
    fontName  = 'Arial';
    figPos    = get(gcf,'Position');
    
    % Modify text
    texts = findall(gcf,'Type','text');
    for k = 1:numel(texts)
        textParent = get(texts(k),'Parent');
        if ~strcmp(get(textParent,'Tag'),'legend')
            set(texts(k), ...
                'FontSize',labelFont, ...
                'FontWeight','bold',...
                'FontName',fontName);
        endif
    endfor
   
    % Set line widths
    figLines = findall(gcf,'Type','line');
    for k = 1:numel(figLines)
        set(figLines(k),'LineWidth',linewidth);
    endfor
    
    % Adjust axes
    figAxes = findall(gcf,'Type','axes');
    for k = 1:numel(figAxes)
        set(figAxes(k), ...
            'LineWidth',linewidth, ...
            'Fontsize',axisFont,...
            'FontWeight','bold', ...
            'FontName',fontName);
    endfor
    
    % Correct figure size
    currPos = get(gcf,'Position');
    newPos  = [currPos(1:2) - (figPos(3:4) - currPos(3:4)) figPos(3:4)];
    set(gcf,'Position',newPos)
    set(gcf,'PaperPosition',[1 1 figPos(3:4)])
    set(gcf,'Units',figUnits)
    
endfunction
